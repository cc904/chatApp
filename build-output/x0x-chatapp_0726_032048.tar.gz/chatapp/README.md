# ChatApp 部署包

## 部署信息
- 镜像名称: `18.183.101.229:15000/x0x-chatapp:latest`
- 构建时间: `2025-07-26 03:20:48`
- 版本: `latest`

## 快速部署

### 1. 启动服务
```bash
docker-compose up -d
```

### 2. 查看日志
```bash
docker-compose logs -f
```

### 3. 停止服务
```bash
docker-compose down
```

### 4. 更新镜像
```bash
docker-compose pull
docker-compose up -d
```

## 访问地址
- 默认访问: http://localhost:8080
- 修改端口: 编辑 .env 文件中的 HOST_PORT

## 环境变量配置
所有配置项请参考 .env 文件中的说明。
